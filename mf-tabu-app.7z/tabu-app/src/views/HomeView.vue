<script setup lang="ts">
import HomeItem from '@/components/HomeItem.vue'
</script>

<template>
  <main>
    <HomeItem></HomeItem>
  </main>
</template>

<script setup lang="ts">
import Login from '@/components/LoginItem.vue'
</script>

<template>
  <main>
    <Login />
  </main>
</template>
